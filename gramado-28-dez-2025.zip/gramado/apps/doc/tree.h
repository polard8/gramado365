
// tree.h

#ifndef __TREE_H
#define __TREE_H    1

unsigned long tree_eval(void);

#endif    


