#ifndef	_DISKTAB_H_
#define	_DISKTAB_H_

 

/*
 * Disk description table, see disktab(5)
 */
#define	_PATH_DISKTAB	"/etc/disktab"

 

#endif /* !_DISKTAB_H_ */


