
 This is a template project to create 
client-side GUI applications for gramado using the libgws.


