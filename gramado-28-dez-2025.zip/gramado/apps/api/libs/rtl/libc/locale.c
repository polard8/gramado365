
// locale.c

#include <stddef.h>

//char *__tmp_locale = "en_US";
//char *__locale = "en_US";

// #todo
char *setlocale (int category, const char *locale)
{
    //__locale = (char *) locale;
    //return (char *) __tmp_locale;
    return "en_US";
}


