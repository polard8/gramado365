/*
 * File: execargs.h 
 * 
 * 
 */


char **execargs = (char**)(-2);



//
// End.
//


