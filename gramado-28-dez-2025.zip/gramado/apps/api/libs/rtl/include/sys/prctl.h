

// #todo

#ifndef __PRCTL_H
#define __PRCTL_H    1


// linux-like process and thread control.
// ??

/*
int prctl (int option, unsigned long arg2, unsigned long arg3,
                 unsigned long arg4, unsigned long arg5);
*/


/*
int gramado_prctl ( int option, unsigned long arg2, unsigned long arg3,
                 unsigned long arg4, unsigned long arg5);
*/


#endif   

