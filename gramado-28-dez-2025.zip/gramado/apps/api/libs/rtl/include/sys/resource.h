


//for id_t
#include <sys/types.h>

int getpriority(int which, id_t who);
int setpriority(int which, id_t who, int prio);




