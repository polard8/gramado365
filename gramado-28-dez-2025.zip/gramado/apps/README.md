# apps - Client-side GUI applications

All the client-side GUI applications are here.

## Folders

```
+ api/      - Gramado API.
              It has libraries and toolkits.
              The main libraries are rtl/ and libgws/.
+ assets/   - OS Shell resources.
+ bin/      - Final images.
+ client    - App
+ cmdline   - App
+ doc       - Text editor
+ editor    - Text editor
+ gdm       - Desktop manager
+ launch    - App for testing a menu
+ menuapp   - App for testing a menu
+ pubterm   - Virtual terminal
+ setup     - Installer
+ taskbar/  - The taskbar.
              The Shell application.
              Desktop, taskbar, filemanager etc
+ templete  - todo
+ term00    - Virtual terminal
+ terminal  - Virtual terminal
+ your      - Resources
```
