
// compiler.h
// Suporte ao compilador usado para construir o shell.

#ifndef __COMPILER
#define __COMPILER    1

int dummycompiler;

#endif    

