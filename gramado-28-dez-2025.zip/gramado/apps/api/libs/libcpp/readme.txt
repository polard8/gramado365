

	Maybe we can create a ring3 library to support
	c++ command line applications.

