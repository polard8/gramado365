exec/

    execXXX() family of functions.
